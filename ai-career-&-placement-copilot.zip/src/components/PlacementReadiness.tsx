import React, { useState } from "react";
import { Sparkles, BarChart2, ShieldCheck, HelpCircle, ArrowRight, AlertTriangle, BookOpen } from "lucide-react";
import { PlacementReadinessResponse } from "../types";
import ActionsConcluder from "./ActionsConcluder";

export default function PlacementReadiness() {
  const [resumeDetails, setResumeDetails] = useState("");
  const [skills, setSkills] = useState("");
  const [projects, setProjects] = useState("");
  const [interviewPerformance, setInterviewPerformance] = useState("Intermediate/Standard");
  const [communication, setCommunication] = useState("Moderate/Active");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<PlacementReadinessResponse | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!skills) {
      setError("Please list at least your core technical skills.");
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch("/api/placement-readiness", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resume: resumeDetails,
          skills,
          projects,
          interviewPerformance,
          communication,
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to calculate placement readiness.");
      }

      const data: PlacementReadinessResponse = await res.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const getMeterColor = (score: number) => {
    if (score >= 80) return "bg-emerald-500";
    if (score >= 60) return "bg-amber-500";
    return "bg-rose-500";
  };

  const getMeterBg = (score: number) => {
    if (score >= 80) return "bg-emerald-50";
    if (score >= 60) return "bg-amber-50";
    return "bg-rose-50";
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="border-b border-slate-100 pb-5">
        <h2 className="text-2xl font-bold font-display text-slate-800">Placement Readiness Index</h2>
        <p className="text-slate-500 text-sm mt-1">Audit your composite placement preparedness rating across all key hiring dimensions.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Form */}
        <form onSubmit={handleSubmit} className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-indigo-600" />
            Audit Parameters
          </h3>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Resume / Profile Overview</label>
            <input
              type="text"
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-xs placeholder:text-slate-400"
              placeholder="e.g. Third year engineering student, 1 simple React project."
              value={resumeDetails}
              onChange={(e) => setResumeDetails(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Core Technical Skills</label>
            <input
              type="text"
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-xs placeholder:text-slate-400"
              placeholder="e.g. JavaScript, CSS, HTML, Node.js"
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Key Projects Built</label>
            <input
              type="text"
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-xs placeholder:text-slate-400"
              placeholder="e.g. E-Commerce Shopping Cart, simple URL Shortener"
              value={projects}
              onChange={(e) => setProjects(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Mock Interview Assessment</label>
            <select
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-xs bg-white"
              value={interviewPerformance}
              onChange={(e) => setInterviewPerformance(e.target.value)}
            >
              <option value="Beginner/Unprepared">Beginner / Unprepared</option>
              <option value="Intermediate/Standard">Intermediate / Standard</option>
              <option value="Advanced/Fully prepared">Advanced / Fully Prepared</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Communication Quality</label>
            <select
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-xs bg-white"
              value={communication}
              onChange={(e) => setCommunication(e.target.value)}
            >
              <option value="Low/Needs training">Low / Needs Training</option>
              <option value="Moderate/Active">Moderate / Active</option>
              <option value="Exceptional/Fluent">Exceptional / Fluent</option>
            </select>
          </div>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-xs text-rose-600 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-2.5 px-4 rounded-xl font-medium text-white text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
              loading ? "bg-slate-400 cursor-not-allowed" : "bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] shadow-md shadow-indigo-100"
            }`}
          >
            {loading ? (
              <>
                <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Auditing Index...
              </>
            ) : (
              <>
                Calculate Readiness Rating
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Right Output */}
        <div className="lg:col-span-7">
          {result ? (
            <div className="space-y-6">
              {/* Overall Placement index Banner */}
              <div className="bg-linear-to-r from-indigo-900 to-slate-900 text-white rounded-3xl p-6 md:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-md shadow-slate-100">
                <div className="space-y-2 text-center sm:text-left">
                  <div className="inline-flex items-center gap-1 bg-indigo-500/30 text-indigo-200 border border-indigo-400/20 px-2.5 py-1 rounded-full text-xs font-semibold">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Overall Readiness Audit
                  </div>
                  <h3 className="text-xl md:text-2xl font-bold font-display">Composite Placement Readiness</h3>
                  <p className="text-slate-300 text-xs leading-relaxed max-w-sm">Weighted calculation across critical performance indices.</p>
                </div>

                <div className="flex flex-col items-center justify-center w-28 h-28 bg-white/10 backdrop-blur-xs border border-white/25 rounded-2xl">
                  <span className="text-4xl font-black text-emerald-400 font-display">{result.overallPlacementReadiness}%</span>
                  <span className="text-[9px] uppercase font-bold text-slate-300 mt-1.5 tracking-wider">Composite Index</span>
                </div>
              </div>

              {/* Sub Score Meters Grid */}
              <div className="bg-white border border-slate-100 rounded-3xl p-6 space-y-5">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Metrics Breakdown</h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {/* Metric 1 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-semibold text-slate-700">
                      <span>Resume Quality</span>
                      <span className="font-bold text-indigo-600">{result.resumeQuality}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                      <div className={`h-full transition-all ${getMeterColor(result.resumeQuality)}`} style={{ width: `${result.resumeQuality}%` }} />
                    </div>
                  </div>

                  {/* Metric 2 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-semibold text-slate-700">
                      <span>Technical Skills Mastery</span>
                      <span className="font-bold text-indigo-600">{result.technicalSkills}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                      <div className={`h-full transition-all ${getMeterColor(result.technicalSkills)}`} style={{ width: `${result.technicalSkills}%` }} />
                    </div>
                  </div>

                  {/* Metric 3 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-semibold text-slate-700">
                      <span>Projects Quality & Depth</span>
                      <span className="font-bold text-indigo-600">{result.projects}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                      <div className={`h-full transition-all ${getMeterColor(result.projects)}`} style={{ width: `${result.projects}%` }} />
                    </div>
                  </div>

                  {/* Metric 4 */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-semibold text-slate-700">
                      <span>Communication & Presentation</span>
                      <span className="font-bold text-indigo-600">{result.communication}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                      <div className={`h-full transition-all ${getMeterColor(result.communication)}`} style={{ width: `${result.communication}%` }} />
                    </div>
                  </div>

                  {/* Metric 5 */}
                  <div className="space-y-2 md:col-span-2">
                    <div className="flex justify-between items-center text-xs font-semibold text-slate-700">
                      <span>Live Board Interview Readiness</span>
                      <span className="font-bold text-indigo-600">{result.interviewReadiness}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                      <div className={`h-full transition-all ${getMeterColor(result.interviewReadiness)}`} style={{ width: `${result.interviewReadiness}%` }} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Detailed Explanation Box */}
              <div className="bg-white border border-slate-100 rounded-3xl p-6">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5">Detailed Audit Verdict</h4>
                <p className="text-slate-600 text-sm leading-relaxed">{result.explanation}</p>
              </div>

              {/* Action Improvement Plan */}
              <div className="bg-white border border-slate-100 rounded-3xl p-6">
                <h4 className="text-xs font-bold text-slate-700 flex items-center gap-2 mb-4 border-b border-slate-100 pb-3">
                  <BookOpen className="w-4.5 h-4.5 text-indigo-500" />
                  Targeted Skill Elevation Strategy
                </h4>
                <ul className="space-y-3.5">
                  {result.improvementPlan.map((plan, idx) => (
                    <li key={idx} className="flex gap-3 text-slate-600 text-xs md:text-sm items-start leading-relaxed">
                      <span className="flex items-center justify-center w-5 h-5 rounded-full bg-indigo-50 text-indigo-600 text-[10px] font-bold mt-0.5 shrink-0">
                        {idx + 1}
                      </span>
                      <span>{plan}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Concluding actions */}
              <ActionsConcluder actions={result.top3Actions} />
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-100 rounded-2xl h-96 flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <div className="w-16 h-16 rounded-2xl bg-white border border-slate-100 flex items-center justify-center mb-4 text-slate-300">
                <BarChart2 className="w-8 h-8" />
              </div>
              <h3 className="font-semibold text-slate-700 mb-1">Index Auditor</h3>
              <p className="text-xs max-w-sm">Provide your technical competencies, project depth, and mock settings to generate your detailed 5-pillar placement matrix.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
