import React, { useState } from "react";
import { Sparkles, Briefcase, UserCheck, AlertTriangle, ArrowRight, Star, Heart, GraduationCap } from "lucide-react";
import { JobRecommendationsResponse } from "../types";
import ActionsConcluder from "./ActionsConcluder";

export default function JobRecommender() {
  const [resumeSummary, setResumeSummary] = useState("");
  const [skills, setSkills] = useState("");
  const [education, setEducation] = useState("");
  const [interests, setInterests] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<JobRecommendationsResponse | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!skills && !resumeSummary) {
      setError("Please provide at least your current skills or a resume summary.");
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch("/api/job-recommendations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resume: resumeSummary,
          skills,
          education,
          interests,
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to fetch job recommendations.");
      }

      const data: JobRecommendationsResponse = await res.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const scoreBadgeColor = (score: number) => {
    if (score >= 85) return "text-emerald-700 bg-emerald-50 border-emerald-100";
    if (score >= 65) return "text-amber-700 bg-amber-50 border-amber-100";
    return "text-indigo-700 bg-indigo-50 border-indigo-100";
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="border-b border-slate-100 pb-5">
        <h2 className="text-2xl font-bold font-display text-slate-800">Job Recommendation Engine</h2>
        <p className="text-slate-500 text-sm mt-1">Discover customized job positions or internships that perfectly align with your current skills and career goals.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Input Form Column */}
        <form onSubmit={handleSubmit} className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-2">
            <UserCheck className="w-4 h-4 text-indigo-600" />
            Your Profile parameters
          </h3>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5 flex items-center gap-1">
              <Briefcase className="w-3.5 h-3.5" /> Resume Details / Experience
            </label>
            <textarea
              className="w-full h-16 px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-xs placeholder:text-slate-400 resize-none"
              placeholder="e.g. 1 year backend developer internship at Startup. Handled Node.js servers."
              value={resumeSummary}
              onChange={(e) => setResumeSummary(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5 flex items-center gap-1">
              <Star className="w-3.5 h-3.5" /> Skills Inventory
            </label>
            <input
              type="text"
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-xs placeholder:text-slate-400"
              placeholder="e.g. Node.js, REST APIs, MongoDB, React, Tailwind CSS"
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5 flex items-center gap-1">
              <GraduationCap className="w-3.5 h-3.5" /> Education
            </label>
            <input
              type="text"
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-xs placeholder:text-slate-400"
              placeholder="e.g. B.S. in Computer Science"
              value={education}
              onChange={(e) => setEducation(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5 flex items-center gap-1">
              <Heart className="w-3.5 h-3.5" /> Core Interests
            </label>
            <input
              type="text"
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-xs placeholder:text-slate-400"
              placeholder="e.g. System Design, Database Optimization, UX research"
              value={interests}
              onChange={(e) => setInterests(e.target.value)}
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-xs text-rose-600 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-2.5 px-4 rounded-xl font-medium text-white text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
              loading ? "bg-slate-400 cursor-not-allowed" : "bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] shadow-md shadow-indigo-100"
            }`}
          >
            {loading ? (
              <>
                <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Matching Jobs...
              </>
            ) : (
              <>
                Recommend Matching Jobs
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Output Panel Column */}
        <div className="lg:col-span-7">
          {result ? (
            <div className="space-y-6">
              <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 text-sm text-emerald-800 font-semibold flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                Identified {result.jobs.length} High-Affinity Jobs
              </div>

              {/* Jobs List */}
              <div className="space-y-5">
                {result.jobs.map((job, idx) => (
                  <div key={idx} className="bg-white border border-slate-100 rounded-2xl p-5 md:p-6 hover:shadow-xs transition-all space-y-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="space-y-1.5">
                        <span className="text-xs font-mono text-indigo-600 font-bold uppercase tracking-wider">Opportunity #{idx + 1}</span>
                        <h3 className="text-lg font-bold text-slate-800 font-display leading-tight">{job.role}</h3>
                      </div>

                      <div className={`flex flex-col items-center justify-center shrink-0 w-16 h-16 border rounded-xl font-display font-extrabold ${scoreBadgeColor(job.matchScore)}`}>
                        <span className="text-xl leading-none">{job.matchScore}%</span>
                        <span className="text-[9px] font-bold tracking-wider uppercase mt-1 opacity-80">Match</span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <span className="text-xs font-bold text-slate-700 block mb-1">Why Recommended:</span>
                        <p className="text-slate-600 text-sm leading-relaxed">{job.whyRecommended}</p>
                      </div>

                      {/* Missing Skills Tags */}
                      {job.missingSkills.length > 0 && (
                        <div>
                          <span className="text-xs font-bold text-slate-700 block mb-1.5">Required Skills to Acquire:</span>
                          <div className="flex flex-wrap gap-1.5">
                            {job.missingSkills.map((sk, sIdx) => (
                              <span key={sIdx} className="text-[10px] bg-slate-50 text-slate-600 border border-slate-200/50 px-2.5 py-0.5 rounded-md font-medium">
                                {sk}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Prep tips */}
                      <div className="p-3 bg-indigo-50/30 rounded-xl border border-indigo-100/30">
                        <span className="text-xs font-semibold text-indigo-900 block mb-1">Application & Interview Tips:</span>
                        <p className="text-slate-600 text-xs leading-relaxed">{job.preparationTips}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Actions */}
              <ActionsConcluder actions={result.top3Actions} />
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-100 rounded-2xl h-96 flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <div className="w-16 h-16 rounded-2xl bg-white border border-slate-100 flex items-center justify-center mb-4 text-slate-300">
                <Briefcase className="w-8 h-8" />
              </div>
              <h3 className="font-semibold text-slate-700 mb-1">Job Engine Active</h3>
              <p className="text-xs max-w-sm">Provide details on your current skills and interests to see customized openings with mock match percentages.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
