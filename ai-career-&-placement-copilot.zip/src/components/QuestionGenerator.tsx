import React, { useState } from "react";
import { Sparkles, HelpCircle, GraduationCap, Star, ArrowRight, AlertTriangle, Play, HelpCircle as HelpIcon, ShieldQuestion } from "lucide-react";
import { InterviewQuestionsResponse, QuestionItem } from "../types";
import ActionsConcluder from "./ActionsConcluder";

export default function QuestionGenerator() {
  const [targetRole, setTargetRole] = useState("AI Intern");
  const [experienceLevel, setExperienceLevel] = useState("Entry Level");
  const [skills, setSkills] = useState("Python, Web Development, Prompt Engineering");
  const [projects, setProjects] = useState("Smart Healthcare System");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<InterviewQuestionsResponse | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetRole) {
      setError("Please specify your target role.");
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch("/api/generate-questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetRole, experienceLevel, skills, projects }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to generate interview questions.");
      }

      const data: InterviewQuestionsResponse = await res.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const difficultyStyle = (difficulty: string) => {
    const d = difficulty.toLowerCase();
    if (d.includes("easy")) return "bg-emerald-50 text-emerald-700 border-emerald-100";
    if (d.includes("hard") || d.includes("difficult")) return "bg-rose-50 text-rose-700 border-rose-100";
    return "bg-amber-50 text-amber-700 border-amber-100"; // Medium/Standard
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="border-b border-slate-100 pb-5">
        <h2 className="text-2xl font-bold font-display text-slate-800">Interview Question Generator</h2>
        <p className="text-slate-500 text-sm mt-1">Acquire an extensive bank of role-specific Technical, Behavioral, and HR questions at multiple difficulty levels.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Form Column */}
        <form onSubmit={handleSubmit} className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-5">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Target Job Role</label>
            <input
              type="text"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-sm placeholder:text-slate-400"
              placeholder="e.g. Software Engineer, QA Architect"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Experience Level</label>
            <select
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-sm bg-white"
              value={experienceLevel}
              onChange={(e) => setExperienceLevel(e.target.value)}
            >
              <option value="Entry Level">Entry Level (0-2 years)</option>
              <option value="Mid Level">Mid Level (2-5 years)</option>
              <option value="Senior Level">Senior Level (5+ years)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Relevant Skills</label>
            <textarea
              className="w-full h-20 px-4 py-3 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-sm font-sans placeholder:text-slate-400 resize-none"
              placeholder="e.g. JavaScript, AWS, System Architecture, Team management"
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Key Projects</label>
            <textarea
              className="w-full h-20 px-4 py-3 rounded-xl border border-slate-200 focus:outline-hidden focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 transition-all text-sm font-sans placeholder:text-slate-400 resize-none"
              placeholder="e.g. Smart Healthcare System, E-commerce App"
              value={projects}
              onChange={(e) => setProjects(e.target.value)}
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-xs text-rose-600 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3 px-4 rounded-xl font-medium text-white flex items-center justify-center gap-2 transition-all cursor-pointer ${
              loading ? "bg-slate-400 cursor-not-allowed" : "bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] shadow-md shadow-indigo-100"
            }`}
          >
            {loading ? (
              <>
                <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Creating Question Bank...
              </>
            ) : (
              <>
                Generate Interview Questions
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Question Bank Column */}
        <div className="lg:col-span-8">
          {result ? (
            <div className="space-y-8">
              {/* Technical Questions block */}
              <div className="space-y-4">
                <h3 className="text-md font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
                  <HelpIcon className="w-5 h-5 text-indigo-600 shrink-0" />
                  {skills ? "Skill-Based Questions" : "Technical Questions"}
                </h3>
                <div className="grid grid-cols-1 gap-3.5">
                  {result.technical.map((item, i) => (
                    <div key={i} className="bg-white border border-slate-100 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs hover:border-slate-200 transition-all">
                      <p className="text-slate-700 text-sm font-medium">{item.question}</p>
                      <span className={`text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full border shrink-0 text-center ${difficultyStyle(item.difficulty)}`}>
                        {item.difficulty}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Behavioral Questions block */}
              <div className="space-y-4">
                <h3 className="text-md font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
                  <ShieldQuestion className="w-5 h-5 text-emerald-600 shrink-0" />
                  Behavioral Questions
                </h3>
                <div className="grid grid-cols-1 gap-3.5">
                  {result.behavioral.map((item, i) => (
                    <div key={i} className="bg-white border border-slate-100 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs hover:border-slate-200 transition-all">
                      <p className="text-slate-700 text-sm font-medium">{item.question}</p>
                      <span className={`text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full border shrink-0 text-center ${difficultyStyle(item.difficulty)}`}>
                        {item.difficulty}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* HR Questions block */}
              <div className="space-y-4">
                <h3 className="text-md font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
                  <Sparkles className="w-5 h-5 text-amber-500 shrink-0" />
                  {projects ? "Project-Based Questions" : "HR Questions"}
                </h3>
                <div className="grid grid-cols-1 gap-3.5">
                  {result.hr.map((item, i) => (
                    <div key={i} className="bg-white border border-slate-100 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs hover:border-slate-200 transition-all">
                      <p className="text-slate-700 text-sm font-medium">{item.question}</p>
                      <span className={`text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full border shrink-0 text-center ${difficultyStyle(item.difficulty)}`}>
                        {item.difficulty}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Concluding actions */}
              <ActionsConcluder actions={result.top3Actions} />
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-100 rounded-2xl h-96 flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <div className="w-16 h-16 rounded-2xl bg-white border border-slate-100 flex items-center justify-center mb-4 text-slate-300">
                <HelpCircle className="w-8 h-8" />
              </div>
              <h3 className="font-semibold text-slate-700 mb-1">Interview Prep Vault</h3>
              <p className="text-xs max-w-sm">Define your target role and skill profile on the left to unpack an extensive question catalog.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
